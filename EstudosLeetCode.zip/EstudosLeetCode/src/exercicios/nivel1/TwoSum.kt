package exercicios.nivel1
fun twoSum(nums: IntArray, target: Int): IntArray {
    val map = HashMap<Int, Int>() // valor -> índice

    for (i in nums.indices) {
        val complemento = target - nums[i]

        if (map.containsKey(complemento)) {
            return intArrayOf(complemento, nums[i])
        }

        map[nums[i]] = i
    }

    throw IllegalArgumentException("Nenhuma solução encontrada")
}

fun main() {
    val nums = intArrayOf(2, 3, 5, 7, 9, 11, 13, 15)
    val target = 18

    val resultado = twoSum(nums, target)
    println(resultado.joinToString())
}

