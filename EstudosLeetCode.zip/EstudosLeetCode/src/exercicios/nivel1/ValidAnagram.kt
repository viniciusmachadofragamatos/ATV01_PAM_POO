package exercicios.nivel1
fun isAnagrama(s: String, t: String): Boolean {
    if (s.length != t.length) return false
    return s.toCharArray().sorted() == t.toCharArray().sorted()
}
fun main () {
    println("String s é anagrama de string t?");
    println(isAnagrama("anagram", "nagaram"))
    println("String s é anagrama de string t?");
    println(isAnagrama("rat", "car"))
}

