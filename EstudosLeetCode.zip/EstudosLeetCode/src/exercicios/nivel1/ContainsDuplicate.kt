package exercicios.nivel1
fun contemDuplicados(nums: IntArray): Boolean {
    val vistos = HashSet<Int>()

    for (num in nums) {
        if (!vistos.add(num)) {
            return true
        }
    }

    return false
}

fun main() {
    val nums1 = intArrayOf(1, 2, 3, 1)
    val nums2 = intArrayOf(1, 2, 3, 4)
    println("Tem valor repetido nums1?");
    println(contemDuplicados(nums1)) // true
    println("Tem valor repetido nums2?");
    println(contemDuplicados(nums2)) // false
}
