package exercicios.nivel3

fun isValid(s: String): Boolean {
    val stack = ArrayDeque<Char>()
    val pairs = mapOf(
        ')' to '(',
        '}' to '{',
        ']' to '['
    )

    for (c in s) {
        if (c in pairs.values) {
            stack.addLast(c)
        } else if (c in pairs.keys) {
            if (stack.isEmpty() || stack.removeLast() != pairs[c]) {
                return false
            }
        }
    }

    return stack.isEmpty()
}
fun main() {
    print("é valido?")
    println(isValid("()"))
    print("é valido?")
    println(isValid("()[]{}"))
    print("é valido?")
    println(isValid("(]"))
    print("é valido?")
    println(isValid("([{}])"))
    print("é valido?")
    println(isValid("([)]"))
}
