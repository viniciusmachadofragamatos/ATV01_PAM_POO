package exercicios.nivel2

fun isPalindromo(s: String): Boolean {
    var left = 0
    var right = s.lastIndex

    while (left < right) {

        // Avança left até achar um caractere alfanumérico
        while (left < right && !s[left].isLetterOrDigit()) {
            left++
        }

        // Regride right até achar um caractere alfanumérico
        while (left < right && !s[right].isLetterOrDigit()) {
            right--
        }

        // Compara ignorando maiúsculas/minúsculas
        if (s[left].lowercaseChar() != s[right].lowercaseChar()) {
            return false
        }

        left++
        right--
    }

    return true
}
fun main () {
    print("s é um palindromo?")
    println(isPalindromo("A man, a plan, a canal: Panama"))
    print("s é um palindromo?")
    println(isPalindromo("race a car"))
    print("s é um palindromo?")
    println(isPalindromo(" "))
}
