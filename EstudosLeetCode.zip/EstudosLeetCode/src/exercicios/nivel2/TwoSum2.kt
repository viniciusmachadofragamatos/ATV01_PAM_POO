package exercicios.nivel2

fun twoSumOrdenado(nums: IntArray, target: Int): IntArray {
    var left = 0
    var right = nums.lastIndex

    while (left < right) {
        val soma = nums[left] + nums[right]

        when {
            soma == target -> return intArrayOf(left, right)
            soma < target -> left++
            else -> right--
        }
    }

    throw IllegalArgumentException("Nenhuma solução encontrada")
}
fun main() {
    val nums = intArrayOf(2, 3, 4, 6, 8)
    val target = 10

    val resultado = twoSumOrdenado(nums, target)
    println(resultado.joinToString()) // Ex.: 1, 3 (3 + 7)
}
